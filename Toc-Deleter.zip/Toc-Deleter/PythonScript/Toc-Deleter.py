#coding:utf-8

#re module import
import re

#Open a file in the same directory
from os import path
a = path.join(path.dirname(__file__), "toc.ncx")

#Open the file
with open(a,"r",encoding="utf-8") as file:
    filedata=file.read()

#Replace
filedata=re.sub('.*\n.*\n.*<text>Page.*\n.*\n.*\n.*\n',"",filedata)

#Write to file
with open(a,"w",encoding="utf-8") as file:
    file.write(filedata)